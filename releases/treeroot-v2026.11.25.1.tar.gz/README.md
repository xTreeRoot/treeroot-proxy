# TreeRoot 代理与管理后台

管理网站：<https://proxy.treeroot.top>。当前服务器为 `186.244.200.45`，协议为 **VMess + WebSocket + TLS**。支持把链接导入 Mac/手机 Clash 以及 Shadowrocket。

本地维护目录：`/Users/xugenyin/file/treeroot-proxy`。后续修改、更新和迁移以此目录为准。

## 最常用的命令

```bash
cd /Users/xugenyin/file/treeroot-proxy
python3 ops/manage.py status       # 检查服务、数据库和静态资源
python3 ops/manage.py backup       # 完整备份，并下载到本机
npm --prefix frontend ci          # 首次安装或锁文件变化后执行
python3 ops/manage.py go-update    # 构建 React/Go、预验证、备份并发布
```

本机需要 Python 3.12+、Go（版本见 `gopanel/go.mod`）、Node.js 20.19+ 或 22.12+、npm 与系统自带 SSH/SCP；运维脚本没有额外 pip 依赖。更新 DNS 时还需要已登录的阿里云 CLI。生产运行 Go 二进制与构建后的静态资源，不需要 Node.js；旧 Python 后端的回退依赖固定在 `requirements.lock`。

## 文档入口

| 文件 | 说明 |
| --- | --- |
| [AGENTS.md](AGENTS.md) | 给后续 Codex/开发者的维护规则和部署入口 |
| [服务器信息](docs/SERVER.md) | IP、DNS、端口、服务、目录、权限、SSH 指纹 |
| [更新与备份](docs/DEPLOYMENT.md) | 发布程序、依赖变更、备份和故障恢复 |
| [BBRx 线路对照记录](docs/NETWORK-20261111.md) | 公司网络测速、固定源码与效果边界 |
| [换服务器](docs/MIGRATION.md) | 备份、恢复新机、测试、切 DNS、回退 |
| [家庭网络](docs/HOME-GATEWAY.md) | 实际接线、Go 家庭程序、正式管理通道、高级规则和验收边界 |
| `deploy/server.json` | 当前 IP、域名、DNS RecordId、固定软件版本 |
| `private/服务器访问说明.md` | 服务器登录方式与交付时密码；只在本机查看 |
| `private/管理后台登录信息.txt` | 后台初始登录信息；改密后以实际密码为准 |
| `private/订阅链接.txt` | 交付时默认用户的订阅链接；后台可复制各用户的当前链接 |
| `private/backups/` | 含数据库、配置、证书的完整恢复包 |

`private/` 含有可登录服务器或使用代理的资料，已排除 Git 跟踪；完整复制文件夹时仍会复制这些资料。

## 后台使用

- “用户与订阅”：新增、重命名、启用/禁用和删除用户，复制 Clash/Shadowrocket 订阅。删除前确认具体用户，删除后停用代理并移至“已删除用户”；身份、订阅凭据、历史流量和访问记录保留，可恢复，恢复后保持停用，需手动启用。桌面每行三张用户卡片，1800px 及以上四张，平板两张、手机一张。筛选、弹窗、表格、数字输入和分页统一使用 Ant Design。每位用户显示创建时间和上次使用时间；上次使用取最近一次代理连接时间，从未建立连接的用户显示“从未使用”，历史时间不随连接明细清理而丢失。每张用户卡片的“流量限制”打开设置弹窗，可设置总流量上限、单日上限（GB）和网速上限（Mbps）。上传与下载合计，总额度包含已有累计，单日按北京时间零点重置；所有设备共享限速和额度，留空或 0 表示不限。额度用尽暂停代理，提高或清除上限即可恢复，单日额度次日自动恢复。默认不限制现有账号。
- “重置订阅”：同时更换链接和节点凭据，保留统计；原设备需导入新链接。
- “运行概览”：查看 CPU、内存、磁盘、持续运行时间，以及主机、系统、运行时和服务状态；包含 SocialCrawlerHub 网站、浏览器服务、数据库及项目目录信息。
- “出口流量大盘”：累计流量、24 小时流量、启用电脑数、24 小时连接数、实时上传/下载六项指标，支持按电脑筛选，查看 24 小时 / 7 天趋势、常用目标和各电脑用量。切换趋势范围不会改变 24 小时卡片。已删除电脑的累计数仍保留，明细按七天保留期计算。
- “代理流量大盘”：按代理用户查看累计流量、24 小时流量与连接数、实时速率、趋势和常用域名。趋势默认最近 24 小时，可按年月日筛选：选年按月、选月按日、选日按小时显示，按浏览器本地时区划分日期，悬浮显示完整日期。筛选只改变趋势，24 小时卡片不变；趋势只提供最近 31 天仍保留的流量明细，早期数据无法追溯。用户使用卡片也显示上次使用时间。与电脑出口流量各自统计。
- “访问记录”：按用户、域名/IP 查看最近 7 天的连接明细。
- “管理设置”：修改管理员密码。

统计按代理身份计算；共享订阅的设备统计会合并。流量来自 Xray 用户计数器，域名来自连接日志，不解密 HTTPS 正文、密码或完整 URL。域名列表提供连接次数，没有每域名字节统计。累计流量及域名汇总保留，分钟流量明细保存 31 天，连接明细保存 7 天。

已有 IP 订阅暂时兼容，更新订阅后节点指向域名。**换服务器前应把客户端订阅链接也改成域名链接**，因为停掉旧 IP 后，旧 IP 订阅地址就无法更新了。

## 项目结构与验证

`gopanel/` 是 Go 服务端，包含管理、订阅、采集、限流、出口接口及每日备份。`frontend/` 是 React + TypeScript + Vite 前端，按 [TailAdmin](https://github.com/TailAdmin/free-react-tailwind-admin-dashboard) 的视觉方向重做八个页面，使用 React Query、Lucide 与本地 ECharts。支持明暗主题、收起侧栏、手机抽屉导航、保留筛选与分页状态，复用原有 cookie/CSRF API。电脑端连接器与 SSH 隧道不变；原 Python 后端保留用于回退和兼容测试。

`npm --prefix frontend run build` 先做 TypeScript 检查，再构建并生成根目录的 `index.html`、`app.js`、`style.css`；缓存版本由内容哈希生成。这三个文件是发布产物，请修改 `frontend/src/` 后重新构建。`go-update` 打包前自动构建前端，避免发布旧资源。字体、图标和图表均不依赖外部 CDN。旧 `egress.js` / `egress.css` 仅保留在原发布白名单以兼容历史包，React 页面不再加载它们。

```bash
npm --prefix frontend ci
npm --prefix frontend run build
npm --prefix frontend test
mkdir -p work
(cd gopanel && go test ./... && go build -trimpath -o ../work/treeroot-gopanel .)
TREEROOT_GO_PANEL_BIN="$PWD/work/treeroot-gopanel" .venv/bin/python -m unittest discover -s tests -v
```

浏览器验收可运行 `.venv/bin/python tests/ui_fixture.py`，在 `http://localhost:19994` 使用脚本内的测试账号；它在 `work/` 创建独立临时数据库，运行实际 Go 接口，不读取或改动生产数据。开发热更新用 `npm --prefix frontend run dev`，默认代理本机 `19992`，可先将该端口改为自己的测试后端端口。

2026-10-30 已完成线上完整备份、备份哈希与 SQLite 校验，以及同版本真实更新：用户身份保留、流量不减少、Xray/Caddy 不重启。新机迁移脚本尚未在另一台 VPS 实机演练，迁移时仍须按文档先验证新机。

## 电脑出口

管理后台新增“电脑出口”：添加当前电脑、下载 10 分钟有效的一次性配对包，解压并双击 `连接.command`（macOS）或 `连接.cmd`（Windows）；也可运行 `python3 connector.py install --setup setup.json`。要求 Python 3.10+ 和 OpenSSH 客户端。macOS 登录后由 LaunchAgent 自动启动；Windows 使用当前用户登录任务。连接器自动重连，不修改系统代理。

服务器通过加密 SSH 反向隧道访问本机认证代理；平台 TLS 不解密，目标只允许公网 TCP 80/443，不可访问电脑局域网。点击“检测出口 IP”可确认实际公网地址。若本机 VPN/TUN 接管了连接器流量，平台会看到 VPN 的出口，需调整本机网络策略。

本机代理对 `accounts.google.com`、`www.google.com` 和 `content-autofill.googleapis.com` 做精确主机快速失败。这些请求来自当前账号浏览器的后台同步或自动填充，不属于平台采集链路；出口明细会记录为“目标主机在当前出口黑名单中”。

复制“应用连接码”到 SocialCrawlerHub 的登录设置，绑定后新账号使用电脑出口；已有账号需点击“应用当前电脑出口”。电脑离线时已绑定任务报错，不回退服务器 IP。连接码相当于该出口的授权凭据，请妥善保管。配对私钥与配置保存于 `~/.treeroot-connector/设备编号/`。卸载命令为 `python3 connector.py uninstall --id 设备编号`，只撤销自动启动并停止任务，保留私钥便于恢复；也应在面板停用出口。

设备支持删除与恢复。“删除”立即撤销配对和新请求授权，记录移至“已删除设备”；恢复后保持停用，需重新配对。首次安装连接器后，登录系统自动建立 SSH 加密连接；页面的“启用并自动连接”恢复已安装连接器的连接。浏览器不能直接运行本机程序，因此新电脑第一次仍需双击下载包中的连接文件。

“电脑出口详细记录”提供按电脑、记录类型、结果及域名/IP 搜索的分页表格，记录设备操作、心跳上线/中断，以及代理连接的目标、端口、方法、结果、上下行字节、耗时与失败原因。记录保留 7 天，不记录完整 URL、请求正文或 TLS 内容；出口 IP 为最近一次人工检测值。已有电脑需重新下载安装新版连接器才会开始上报连接明细；连接结束后上报，断网时在电脑本地暂存，恢复连接后重试并去重，本机队列最多保留 7 天、10,000 条。

出口大盘汇总每 15 秒刷新，按连接结束时间汇总已上报记录；进行中的长连接及尚未补报的离线数据会延后入账。累计流量首次升级从仍保留的连接记录回填，以后长期保留，不随七天明细清理而减少。上传指电脑发送到目标的字节，下载指目标返回电脑的字节；成功率代表代理成功建立目标连接，不代表目标网站的业务请求成功。设备事件不计入流量和连接数，无连接时成功率显示“—”。

实时上传/下载每 5 秒采样，包含正在传输的连接；连接器重启后需要两次采样建立基线。已有电脑需重新下载安装连接器才能上报实时速率。旧连接器继续兼容，页面会显示等待采样或实际覆盖的电脑数量；15 秒未收到采样即不再采用旧速率。

## 源码备份包与清理

`releases/` 是仓库内的完整源码备份，只留最新两版，包含来源提交与逐文件 SHA256，不含生产数据和秘密。先提交源码，再执行 `python3 ops/releases.py pack vYYYY.MM.DD.N --ref 源码提交` 并提交生成包。运行 `python3 ops/releases.py sync` 将两版同步到服务器 `/root/treeroot-ops/releases`。

`python3 ops/manage.py cleanup` 查看旧源码包与缓存清理计划，`cleanup --apply` 执行。两份源码包验证通过后才允许清理；数据库、配置、证书、访问日志和完整运维备份保留。

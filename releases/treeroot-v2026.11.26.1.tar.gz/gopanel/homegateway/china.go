package homegateway

// GEOIP resolves domains not covered by the explicit list so a domestic address
// can still go direct. no-resolve remains available for user-supplied patches.
const ChinaDirectPatch = `prepend:
  - 'DOMAIN,localhost,DIRECT'
  - 'DOMAIN-SUFFIX,local,DIRECT'
  - 'IP-CIDR,127.0.0.0/8,DIRECT,no-resolve'
  - 'IP-CIDR,10.0.0.0/8,DIRECT,no-resolve'
  - 'IP-CIDR,172.16.0.0/12,DIRECT,no-resolve'
  - 'IP-CIDR,192.168.0.0/16,DIRECT,no-resolve'
  - 'IP-CIDR,169.254.0.0/16,DIRECT,no-resolve'
  - 'DOMAIN-SUFFIX,cn,DIRECT'
  - 'DOMAIN-SUFFIX,baidu.com,DIRECT'
  - 'DOMAIN-SUFFIX,qq.com,DIRECT'
  - 'DOMAIN-SUFFIX,weixin.com,DIRECT'
  - 'DOMAIN-SUFFIX,alicdn.com,DIRECT'
  - 'DOMAIN-SUFFIX,aliyun.com,DIRECT'
  - 'DOMAIN-SUFFIX,alipay.com,DIRECT'
  - 'DOMAIN-SUFFIX,taobao.com,DIRECT'
  - 'DOMAIN-SUFFIX,tmall.com,DIRECT'
  - 'DOMAIN-SUFFIX,jd.com,DIRECT'
  - 'DOMAIN-SUFFIX,163.com,DIRECT'
  - 'DOMAIN-SUFFIX,126.com,DIRECT'
  - 'DOMAIN-SUFFIX,bilibili.com,DIRECT'
  - 'DOMAIN-SUFFIX,bilivideo.com,DIRECT'
  - 'DOMAIN-SUFFIX,douyin.com,DIRECT'
  - 'DOMAIN-SUFFIX,douyinvod.com,DIRECT'
  - 'DOMAIN-SUFFIX,xiaohongshu.com,DIRECT'
  - 'DOMAIN-SUFFIX,feishu.cn,DIRECT'
  - 'DOMAIN-SUFFIX,dingtalk.com,DIRECT'
  - 'DOMAIN-SUFFIX,amap.com,DIRECT'
  - 'DOMAIN-SUFFIX,mi.com,DIRECT'
  - 'DOMAIN-SUFFIX,meituan.com,DIRECT'
  - 'DOMAIN-SUFFIX,dianping.com,DIRECT'
  - 'DOMAIN-SUFFIX,zhihu.com,DIRECT'
  - 'GEOIP,CN,DIRECT'
append: []
delete: []
`

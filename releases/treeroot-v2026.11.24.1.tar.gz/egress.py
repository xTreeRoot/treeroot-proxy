"""管理电脑出口配对、受限 SSH 身份及供本机采集服务读取的出口登记。"""
import base64
import hashlib
import hmac
import io
import ipaddress
import json
import os
from pathlib import Path
import re
import secrets
import socket
import sqlite3
import subprocess
import threading
import time
from typing import Literal
import uuid
import zipfile

from fastapi import Depends, HTTPException, Query, Request, Response
from pydantic import BaseModel, Field
from connector_version import CONNECTOR_VERSION


class BrowserInfo(BaseModel):
    """用户网页浏览器公开的设备信息，不接收 Cookie、可执行路径或代理地址。"""
    userAgent: str = Field(default='', max_length=512)
    platform: str = Field(default='', max_length=64)
    language: str = Field(default='zh-CN', max_length=35)
    timezone: str = Field(default='Asia/Shanghai', max_length=80)
    platformName: str = Field(default='', max_length=32)
    platformVersion: str = Field(default='', max_length=32)
    architecture: str = Field(default='', max_length=16)
    bitness: str = Field(default='', max_length=8)
    width: int = Field(default=1280, ge=320, le=7680)
    height: int = Field(default=900, ge=240, le=4320)


class NewEgress(BaseModel):
    name: str = Field(min_length=1, max_length=64)
    browser: BrowserInfo = Field(default_factory=BrowserInfo)


class PairEgress(BaseModel):
    token: str = Field(min_length=20, max_length=128)
    public_key: str = Field(min_length=40, max_length=256)


class UpdateEgress(BaseModel):
    enabled: bool


class NewBlacklistHost(BaseModel):
    host: str = Field(min_length=1, max_length=253)


class UpdateBlacklistHost(BaseModel):
    host: str | None = Field(default=None, min_length=1, max_length=253)
    enabled: bool | None = None


class ConnectionRecord(BaseModel):
    event_key: str = Field(pattern=r'^[a-f0-9]{32}$')
    ts: int = Field(ge=0)
    domain: str = Field(default='', max_length=253, pattern=r'^[a-zA-Z0-9.:%_-]*$')
    port: int | None = Field(default=None, ge=1, le=65535)
    method: str = Field(default='', max_length=16, pattern=r'^[A-Z]*$')
    outcome: Literal['success', 'failed']
    upload: int = Field(default=0, ge=0, le=2**53 - 1)
    download: int = Field(default=0, ge=0, le=2**53 - 1)
    duration_ms: int = Field(default=0, ge=0, le=2**53 - 1)
    detail: Literal['', 'invalid_request', 'target_rejected', 'target_blacklisted', 'connection_failed', 'timeout', 'interrupted'] = ''


class LiveTraffic(BaseModel):
    run_id: str = Field(pattern=r'^[a-f0-9]{32}$')
    sampled_at: float = Field(ge=0, allow_inf_nan=False)
    upload: int = Field(ge=0, le=2**53 - 1)
    download: int = Field(ge=0, le=2**53 - 1)


class HeartbeatEgress(BaseModel):
    records: list[ConnectionRecord] = Field(default_factory=list, max_length=100)
    traffic: LiveTraffic | None = None
    driver_version: str | None = Field(default=None, max_length=32,
                                       pattern=r'^v\d{4}\.\d{2}\.\d{2}\.\d+$')


DEFAULT_BLACKLIST_HOSTS = (
    'accounts.google.com',
    'www.google.com',
    'content-autofill.googleapis.com',
)
HOST_LABEL = r'[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?'
HOST_PATTERN = re.compile(r'^(?:' + HOST_LABEL + r'\.)*' + HOST_LABEL + r'$')


def normalize_blacklist_host(value: str) -> str:
    host = value.strip().lower()
    try:
        ipaddress.ip_address(host)
        is_ip = True
    except ValueError:
        is_ip = False
    if is_ip or len(host) > 253 or not HOST_PATTERN.fullmatch(host):
        raise HTTPException(422, '黑名单只接受精确主机名，不支持协议、端口、路径、通配符或 IP')
    return host


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


class Egress:
    def __init__(self, database, config, data, root):
        self.database, self.config, self.root = database, config, root
        self.directory = Path(config.get('egress_dir', str(data / 'egress')))
        self.rate_lock = threading.Lock()
        self.live = {}

    def initialize(self, data=None):
        """仅新增独立表，既有代理身份、会话及统计不做迁移或重置。"""
        if data is not None and not self.config.get('egress_dir'):
            self.directory = Path(data) / 'egress'
        with self.database() as db:
            db.execute('''CREATE TABLE IF NOT EXISTS egress_devices(
              id TEXT PRIMARY KEY,name TEXT NOT NULL,port INTEGER NOT NULL UNIQUE,
              enabled INTEGER NOT NULL DEFAULT 1,deleted INTEGER NOT NULL DEFAULT 0,created INTEGER NOT NULL,
              browser TEXT NOT NULL,access_code TEXT NOT NULL,proxy_password TEXT NOT NULL,
              pair_hash TEXT,pair_expires INTEGER,public_key TEXT,agent_hash TEXT,
              last_seen INTEGER,last_ip TEXT,last_test INTEGER,driver_version TEXT)''')
            device_columns = {row[1] for row in db.execute('PRAGMA table_info(egress_devices)')}
            if 'deleted' not in device_columns:
                db.execute('ALTER TABLE egress_devices ADD COLUMN deleted INTEGER NOT NULL DEFAULT 0')
            if 'driver_version' not in device_columns:
                db.execute('ALTER TABLE egress_devices ADD COLUMN driver_version TEXT')
            db.execute('''CREATE TABLE IF NOT EXISTS egress_events(
              id INTEGER PRIMARY KEY AUTOINCREMENT,event_key TEXT NOT NULL,
              device_id TEXT NOT NULL REFERENCES egress_devices(id),ts INTEGER NOT NULL,
              kind TEXT NOT NULL,action TEXT NOT NULL,outcome TEXT NOT NULL,
              domain TEXT NOT NULL DEFAULT '',port INTEGER,method TEXT NOT NULL DEFAULT '',
              upload INTEGER NOT NULL DEFAULT 0,download INTEGER NOT NULL DEFAULT 0,
              duration_ms INTEGER NOT NULL DEFAULT 0,exit_ip TEXT NOT NULL DEFAULT '',
              detail TEXT NOT NULL DEFAULT '',UNIQUE(device_id,event_key))''')
            db.execute('CREATE INDEX IF NOT EXISTS egress_events_device_id ON egress_events(device_id,id DESC)')
            db.execute('CREATE INDEX IF NOT EXISTS egress_events_time ON egress_events(ts)')
            db.execute("CREATE INDEX IF NOT EXISTS egress_request_cursor ON egress_events(device_id,id) WHERE kind='request'")
            db.execute('''CREATE TABLE IF NOT EXISTS egress_totals(
                device_id TEXT PRIMARY KEY REFERENCES egress_devices(id),
                upload INTEGER NOT NULL,download INTEGER NOT NULL,connections INTEGER NOT NULL,
                last_event_id INTEGER NOT NULL,since INTEGER NOT NULL)''')
            db.execute('''CREATE TABLE IF NOT EXISTS egress_blacklist(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                host TEXT NOT NULL UNIQUE,
                enabled INTEGER NOT NULL DEFAULT 1,
                created INTEGER NOT NULL,
                updated INTEGER NOT NULL)''')
            now = int(time.time())
            db.executemany('''INSERT OR IGNORE INTO egress_blacklist(host,enabled,created,updated)
                              VALUES(?,?,?,?)''', [(host, 1, now, now) for host in DEFAULT_BLACKLIST_HOSTS])
            self.sync_totals(db)
        with self.rate_lock:
            self.live.clear()
        self.publish()

    def sync_totals(self, db, device_id=None):
        """Use an event ID checkpoint so retries, restarts and retention never recount bytes."""
        if not db.in_transaction:
            db.execute('BEGIN IMMEDIATE')
        db.execute('''INSERT INTO egress_totals(device_id,upload,download,connections,last_event_id,since)
            SELECT d.id,SUM(e.upload),SUM(e.download),COUNT(*),MAX(e.id),MIN(e.ts)
            FROM egress_devices d LEFT JOIN egress_totals t ON t.device_id=d.id
            CROSS JOIN egress_events e
            WHERE e.device_id=d.id AND e.id>COALESCE(t.last_event_id,0) AND e.kind='request' ''' +
            (' AND d.id=? ' if device_id else '') + '''GROUP BY d.id
            ON CONFLICT(device_id) DO UPDATE SET upload=upload+excluded.upload,
            download=download+excluded.download,connections=connections+excluded.connections,
            last_event_id=excluded.last_event_id,since=MIN(since,excluded.since)''', [device_id] if device_id else [])

    def sample_traffic(self, device_id, traffic, now):
        if traffic is None:
            return
        sample = traffic.model_dump()
        with self.rate_lock:
            previous = self.live.get(device_id)
            if previous and previous['run_id'] == sample['run_id'] and sample['sampled_at'] <= previous['sampled_at']:
                return
            speed = None
            if (previous and previous['run_id'] == sample['run_id']
                    and sample['upload'] >= previous['upload'] and sample['download'] >= previous['download']
                    and now - previous['received_at'] < 15):
                elapsed = sample['sampled_at'] - previous['sampled_at']
                if 0 < elapsed <= 15:
                    speed = {key: (sample[key] - previous[key]) / elapsed for key in ('upload', 'download')}
            self.live[device_id] = sample | {'received_at': now, 'speed': speed}

    def rates(self, rows, now):
        online = [row for row in rows if not row['deleted'] and row['enabled'] and row['public_key']
                  and row['last_seen'] and now - row['last_seen'] < 65]
        with self.rate_lock:
            fresh = [self.live[row['id']]['speed'] for row in online
                     if row['id'] in self.live and now - self.live[row['id']]['received_at'] < 15
                     and self.live[row['id']]['speed'] is not None]
        return {'speed_upload': sum(item['upload'] for item in fresh) if fresh or not online else None,
                'speed_download': sum(item['download'] for item in fresh) if fresh or not online else None,
                'live_devices': len(fresh), 'online_devices': len(online), 'sampled_at': now}

    def event(self, db, row, action, outcome='success', detail='', ts=None, event_key=None):
        db.execute('''INSERT OR IGNORE INTO egress_events
            (event_key,device_id,ts,kind,action,outcome,exit_ip,detail) VALUES(?,?,?,'device',?,?,?,?)''',
            (event_key or uuid.uuid4().hex, row['id'], ts if ts is not None else int(time.time()),
             action, outcome, row['last_ip'] or '', detail))

    def disconnected(self, db, row, now):
        if row['last_seen'] and now - row['last_seen'] >= 65:
            self.event(db, row, 'disconnected', ts=row['last_seen'] + 65,
                       event_key='offline:' + str(row['last_seen']))

    def maintain(self):
        now = int(time.time())
        with self.database() as db:
            self.sync_totals(db)
            for row in db.execute('''SELECT * FROM egress_devices WHERE enabled=1 AND deleted=0
                                     AND public_key IS NOT NULL AND last_seen<=?''', (now - 65,)):
                self.disconnected(db, row, now)
            db.execute('DELETE FROM egress_events WHERE ts<?', (now - 7 * 86400,))

    def publish(self):
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o750)
        with self.database(readonly=True) as db:
            rows = db.execute('SELECT * FROM egress_devices WHERE deleted=0').fetchall()
        devices = [{
            'id': r['id'], 'name': r['name'], 'enabled': bool(r['enabled']),
            'accessHash': digest(r['access_code']), 'lastSeen': r['last_seen'],
            'browser': json.loads(r['browser']),
            'proxy': {'server': f"http://127.0.0.1:{r['port']}",
                      'username': r['id'], 'password': r['proxy_password']},
            'publicKey': r['public_key'], 'port': r['port'],
        } for r in rows]
        target = self.directory / 'registry.json'
        temporary = self.directory / ('registry-' + secrets.token_hex(8) + '.tmp')
        try:
            with open(temporary, 'x') as out:
                os.chmod(temporary, 0o640)
                json.dump({'version': 1, 'devices': devices}, out, ensure_ascii=False)
            os.replace(temporary, target)
        finally:
            temporary.unlink(missing_ok=True)

    def row(self, device_id, db):
        row = db.execute('SELECT * FROM egress_devices WHERE id=?', (device_id,)).fetchone()
        if not row or row['deleted']:
            raise HTTPException(404, '出口设备不存在')
        return row

    def summary(self, row):
        online = bool(row['enabled'] and row['public_key'] and row['last_seen'] and time.time() - row['last_seen'] < 65)
        return {key: row[key] for key in ('id', 'name', 'created', 'last_seen', 'last_ip', 'last_test', 'driver_version')} | {
            'enabled': bool(row['enabled']), 'paired': bool(row['public_key']), 'online': online,
            'browser': json.loads(row['browser']),
        }

    def authenticate_agent(self, device_id, request, db):
        row = self.row(device_id, db)
        token = request.headers.get('authorization', '').removeprefix('Bearer ')
        if not row['enabled'] or not row['agent_hash'] or not hmac.compare_digest(row['agent_hash'], digest(token)):
            raise HTTPException(403, '出口连接已停用或凭据无效')
        return row

    def blacklist(self, db, enabled_only=False):
        query = 'SELECT id,host,enabled,created,updated FROM egress_blacklist'
        if enabled_only:
            query += ' WHERE enabled=1'
        query += ' ORDER BY host,id'
        return [dict(row) | {'enabled': bool(row['enabled'])}
                for row in db.execute(query).fetchall()]


def install_routes(app, database, authenticated, config, data, root, report_database):
    manager = Egress(database, config, data, root)

    @app.get('/api/egress')
    def devices(deleted: bool = False, session=Depends(authenticated)):
        with database(readonly=True) as db:
            return [manager.summary(row) for row in db.execute('SELECT * FROM egress_devices WHERE deleted=? ORDER BY created,id', (deleted,))]

    @app.get('/api/egress/overview')
    def overview(device_id: str = '', hours: str = '24', session=Depends(authenticated)):
        # A restored mobile select may send an empty value instead of omitting the query.
        period = str(hours).strip() or '24'
        if period not in ('24', '168'):
            raise HTTPException(422, '统计范围仅支持最近 24 小时或 7 天')
        hours = int(period)
        now = int(time.time())
        since = now - hours * 3600
        where = " WHERE kind='request' AND ts>=? AND ts<=?"
        args = [since, now]
        if device_id:
            where += ' AND device_id=?'
            args.append(device_id)
        with report_database() as db:
            # Keep cards, charts and rankings on the same SQLite read snapshot.
            db.execute('BEGIN')
            rows = db.execute('''SELECT id,name,deleted,enabled,public_key,last_seen,driver_version
                                 FROM egress_devices ORDER BY deleted,created,id''').fetchall()
            if device_id and not any(row['id'] == device_id for row in rows):
                raise HTTPException(404, '出口设备不存在')
            grouped = {row['device_id']: dict(row) for row in db.execute('''SELECT device_id,
                SUM(upload) upload,SUM(download) download,COUNT(*) connections,
                SUM(outcome='success') succeeded,MAX(ts) last_record
                FROM egress_events''' + where + ' GROUP BY device_id', args)}
            day = dict(db.execute('''SELECT COALESCE(SUM(upload),0) day_upload,
                COALESCE(SUM(download),0) day_download,COUNT(*) day_connections,
                COALESCE(SUM(outcome='success'),0) day_succeeded FROM egress_events
                WHERE kind='request' AND ts>=? AND ts<=?''' +
                (' AND device_id=?' if device_id else ''),
                [now - 86400, now, *([device_id] if device_id else [])]).fetchone())
            cumulative = dict(db.execute('''SELECT COALESCE(SUM(upload),0) total_upload,
                COALESCE(SUM(download),0) total_download,MIN(since) total_since FROM egress_totals''' +
                (' WHERE device_id=?' if device_id else ''), [device_id] if device_id else []).fetchone())
            hourly = {row['bucket']: dict(row) for row in db.execute('''SELECT
                MIN(CAST((ts-?)/3600 AS INTEGER),?) bucket,
                SUM(upload) upload,SUM(download) download,COUNT(*) connections
                FROM egress_events''' + where + ' GROUP BY bucket', [since, hours - 1, *args])}
            domains = [dict(row) for row in db.execute('''SELECT domain,COUNT(*) connections,
                SUM(upload) upload,SUM(download) download FROM egress_events''' + where +
                " AND domain<>'' GROUP BY domain ORDER BY connections DESC,domain LIMIT 12", args)]
        devices = []
        for row in rows:
            if device_id and row['id'] != device_id:
                continue
            item = {key: row[key] for key in ('id', 'name', 'last_seen', 'driver_version')}
            item.update(deleted=bool(row['deleted']), enabled=bool(row['enabled']),
                        online=bool(not row['deleted'] and row['enabled'] and row['public_key']
                                    and row['last_seen'] and now - row['last_seen'] < 65))
            item.update(grouped.get(row['id'], {'upload': 0, 'download': 0, 'connections': 0,
                                                'succeeded': 0, 'last_record': None}))
            item.pop('device_id', None)
            devices.append(item)
        totals = {key: sum(item[key] for item in devices)
                  for key in ('upload', 'download', 'connections', 'succeeded')}
        devices.sort(key=lambda item: (-(item['upload'] + item['download']), item['name'], item['id']))
        return totals | day | cumulative | manager.rates([r for r in rows if not device_id or r['id'] == device_id], now) | {
            'since': since, 'until': now, 'hours': hours,
            'online': sum(item['online'] for item in devices),
            'available': sum(not item['deleted'] for item in devices),
            'enabled': sum(item['enabled'] and not item['deleted'] for item in devices),
            'last_record': max((item['last_record'] or 0 for item in devices), default=0) or None,
            'device_options': [{key: row[key] for key in ('id', 'name', 'deleted')} for row in rows],
            'devices': devices, 'domains': domains,
            'series': [{'ts': since + i * 3600, 'upload': hourly.get(i, {}).get('upload', 0),
                        'download': hourly.get(i, {}).get('download', 0),
                        'connections': hourly.get(i, {}).get('connections', 0)} for i in range(hours)],
        }

    @app.get('/api/egress/rates')
    def rates(device_id: str = '', session=Depends(authenticated)):
        with database(readonly=True) as db:
            rows = db.execute('SELECT id,enabled,deleted,public_key,last_seen FROM egress_devices' +
                              (' WHERE id=?' if device_id else ''), [device_id] if device_id else []).fetchall()
        if device_id and not rows:
            raise HTTPException(404, '出口设备不存在')
        return manager.rates(rows, int(time.time()))

    @app.get('/api/egress/records')
    def records(device_id: str = '', kind: Literal['', 'request', 'device'] = '',
                outcome: Literal['', 'success', 'failed'] = '', search: str = Query(default='', max_length=253),
                start: int | None = Query(default=None, ge=0), end: int | None = Query(default=None, ge=0),
                page: int = Query(default=1, ge=1), page_size: int = Query(default=25, ge=1, le=100),
                before_id: int | None = Query(default=None, ge=1), session=Depends(authenticated)):
        if start is not None and end is not None and start > end:
            raise HTTPException(422, '开始时间不能晚于结束时间')
        clauses, args = ['e.ts>=?'], [max(start or 0, int(time.time()) - 7 * 86400)]
        for column, value in [('device_id', device_id), ('kind', kind), ('outcome', outcome)]:
            if value:
                clauses.append('e.' + column + '=?')
                args.append(value)
        if end is not None:
            clauses.append('e.ts<=?')
            args.append(end)
        if search.strip():
            clauses.append("(e.domain LIKE ? ESCAPE '\\' OR e.exit_ip LIKE ? ESCAPE '\\')")
            pattern = '%' + search.strip().replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_') + '%'
            args.extend([pattern, pattern])
        with report_database() as db:
            if before_id is None:
                before_id = db.execute('SELECT MAX(e.id) FROM egress_events e WHERE ' + ' AND '.join(clauses), args).fetchone()[0]
            clauses.append('e.id<=?')
            args.append(before_id or 0)
            where = ' WHERE ' + ' AND '.join(clauses)
            total = db.execute('SELECT COUNT(*) FROM egress_events e' + where, args).fetchone()[0]
            pages = max(1, (total + page_size - 1) // page_size)
            page = min(page, pages)
            items = [dict(row) for row in db.execute('''SELECT e.*,d.name FROM
                (SELECT * FROM egress_events e''' + where + ''' ORDER BY e.id DESC LIMIT ? OFFSET ?) e
                JOIN egress_devices d ON d.id=e.device_id ORDER BY e.id DESC''',
                [*args, page_size, (page - 1) * page_size])]
        for item in items:
            item.pop('event_key')
        return {'items': items, 'total': total, 'page': page, 'page_size': page_size,
                'pages': pages, 'before_id': before_id}

    @app.get('/api/egress/blacklist')
    def blacklist(session=Depends(authenticated)):
        with database(readonly=True) as db:
            return manager.blacklist(db)

    @app.post('/api/egress/blacklist')
    def create_blacklist(body: NewBlacklistHost, session=Depends(authenticated)):
        host = normalize_blacklist_host(body.host)
        now = int(time.time())
        try:
            with database() as db:
                cursor = db.execute('''INSERT INTO egress_blacklist(host,enabled,created,updated)
                                      VALUES(?,?,?,?)''', (host, 1, now, now))
                result = dict(db.execute('''SELECT id,host,enabled,created,updated
                                            FROM egress_blacklist WHERE id=?''', (cursor.lastrowid,)).fetchone())
        except sqlite3.IntegrityError:
            raise HTTPException(409, '该主机已在出口黑名单中')
        result['enabled'] = bool(result['enabled'])
        return result

    @app.patch('/api/egress/blacklist/{blacklist_id}')
    def update_blacklist(blacklist_id: int, body: UpdateBlacklistHost, session=Depends(authenticated)):
        host = normalize_blacklist_host(body.host) if body.host is not None else None
        if host is None and body.enabled is None:
            raise HTTPException(422, '至少提供主机名或启用状态')
        now = int(time.time())
        try:
            with database() as db:
                current = db.execute('SELECT * FROM egress_blacklist WHERE id=?', (blacklist_id,)).fetchone()
                if not current:
                    raise HTTPException(404, '出口黑名单规则不存在')
                fields, values = [], []
                if host is not None:
                    fields.append('host=?')
                    values.append(host)
                if body.enabled is not None:
                    fields.append('enabled=?')
                    values.append(body.enabled)
                fields.append('updated=?')
                values.extend([now, blacklist_id])
                db.execute('UPDATE egress_blacklist SET ' + ','.join(fields) + ' WHERE id=?', values)
                result = dict(db.execute('''SELECT id,host,enabled,created,updated
                                            FROM egress_blacklist WHERE id=?''', (blacklist_id,)).fetchone())
        except sqlite3.IntegrityError:
            raise HTTPException(409, '该主机已在出口黑名单中')
        result['enabled'] = bool(result['enabled'])
        return result

    @app.delete('/api/egress/blacklist/{blacklist_id}')
    def delete_blacklist(blacklist_id: int, session=Depends(authenticated)):
        with database() as db:
            result = db.execute('DELETE FROM egress_blacklist WHERE id=?', (blacklist_id,))
            if not result.rowcount:
                raise HTTPException(404, '出口黑名单规则不存在')
        return {'ok': True}

    @app.post('/api/egress')
    def create(body: NewEgress, session=Depends(authenticated)):
        name = body.name.strip()
        if not name:
            raise HTTPException(422, '请输入电脑名称')
        with database() as db:
            db.execute('BEGIN IMMEDIATE')
            ports = {row[0] for row in db.execute('SELECT port FROM egress_devices')}
            port = None
            for candidate in range(21000, 22000):
                if candidate in ports:
                    continue
                with socket.socket() as probe:
                    try:
                        probe.bind(('127.0.0.1', candidate))
                    except OSError:
                        continue
                port = candidate
                break
            if port is None:
                raise HTTPException(409, '出口连接数量已达上限')
            device_id = uuid.uuid4().hex
            db.execute('''INSERT INTO egress_devices(id,name,port,created,browser,access_code,proxy_password)
                          VALUES(?,?,?,?,?,?,?)''', (device_id, name, port, int(time.time()),
                          body.browser.model_dump_json(), secrets.token_urlsafe(32), secrets.token_urlsafe(32)))
            row = manager.row(device_id, db)
            manager.event(db, row, 'created')
            result = manager.summary(row)
        manager.publish()
        return result

    @app.patch('/api/egress/{device_id}')
    def update(device_id: str, body: UpdateEgress, session=Depends(authenticated)):
        with database() as db:
            row = manager.row(device_id, db)
            if bool(row['enabled']) != body.enabled:
                manager.event(db, row, 'enabled' if body.enabled else 'disabled')
            db.execute('UPDATE egress_devices SET enabled=? WHERE id=?', (body.enabled, device_id))
            result = manager.summary(manager.row(device_id, db))
        with manager.rate_lock:
            manager.live.pop(device_id, None)
        manager.publish()
        return result

    @app.delete('/api/egress/{device_id}')
    def remove(device_id: str, session=Depends(authenticated)):
        with database() as db:
            row = manager.row(device_id, db)
            manager.event(db, row, 'deleted')
            db.execute("""UPDATE egress_devices SET deleted=1,enabled=0,public_key=NULL,
                agent_hash=NULL,pair_hash=NULL,pair_expires=NULL,last_seen=NULL,driver_version=NULL WHERE id=?""", (device_id,))
        manager.publish()
        return {'ok': True}

    @app.post('/api/egress/{device_id}/restore')
    def restore(device_id: str, session=Depends(authenticated)):
        with database() as db:
            result = db.execute('UPDATE egress_devices SET deleted=0,enabled=0 WHERE id=? AND deleted=1', (device_id,))
            if not result.rowcount:
                raise HTTPException(404, '已删除设备不存在')
            manager.event(db, manager.row(device_id, db), 'restored')
        manager.publish()
        return {'ok': True}

    @app.get('/api/egress/{device_id}/access-code')
    def access_code(device_id: str, session=Depends(authenticated)):
        with database(readonly=True) as db:
            return {'code': manager.row(device_id, db)['access_code']}

    @app.post('/api/egress/{device_id}/setup')
    def setup(device_id: str, session=Depends(authenticated)):
        if not config.get('egress_ssh_host') or not config.get('egress_known_hosts'):
            raise HTTPException(503, '服务器出口连接尚未完成部署')
        token = secrets.token_urlsafe(32)
        with database() as db:
            row = manager.row(device_id, db)
            if not row['enabled']:
                raise HTTPException(409, '请先启用出口设备')
            db.execute('UPDATE egress_devices SET pair_hash=?,pair_expires=? WHERE id=?',
                       (digest(token), int(time.time()) + 600, device_id))
            manager.event(db, row, 'setup_downloaded')
        archive = io.BytesIO()
        with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as bundle:
            for name in ('connector.py', 'connector_version.py', 'egress_proxy.py'):
                bundle.write(root / name, name)
            bundle.writestr('连接.command', '#!/bin/bash\ncd "$(dirname "$0")"\npython3 connector.py install --setup setup.json\nresult=$?\nif [ "$result" -ne 0 ]; then echo "连接失败，请查看上面的提示后重新下载连接包。"; fi\nread -r -p "按回车关闭窗口"\nexit "$result"\n')
            bundle.writestr('连接.cmd', '@echo off\r\ncd /d "%~dp0"\r\npy -3 connector.py install --setup setup.json\r\npause\r\n')
            bundle.writestr('setup.json', json.dumps({'base_url': config['base_url'], 'id': device_id,
                                                       'token': token, 'driver_version': CONNECTOR_VERSION}))
            bundle.writestr('使用说明.txt', '请在本机解压，10 分钟内运行：\nmacOS：双击 连接.command\nWindows：双击 连接.cmd\n需要 Python 3.10+ 和 OpenSSH 客户端。安装后当前用户登录系统时自动连接。\n卸载：python3 connector.py uninstall --id ' + device_id + '\n')
            for name in ('连接.command',):
                bundle.getinfo(name).external_attr = 0o100755 << 16
        return Response(archive.getvalue(), media_type='application/zip',
                        headers={'Content-Disposition': 'attachment; filename=TreeRoot-Connector.zip'})

    @app.post('/api/egress/{device_id}/pair')
    def pair(device_id: str, body: PairEgress):
        fields = body.public_key.strip().split()
        if len(fields) != 2 or fields[0] != 'ssh-ed25519' or not re.fullmatch(r'[A-Za-z0-9+/]+={0,2}', fields[1]):
            raise HTTPException(422, '只接受新生成的 Ed25519 公钥')
        try:
            blob = base64.b64decode(fields[1], validate=True)
            if len(blob) != 51 or blob[:19] != b'\x00\x00\x00\x0bssh-ed25519\x00\x00\x00\x20':
                raise ValueError()
        except ValueError:
            raise HTTPException(422, '公钥内容无效')
        agent_token = secrets.token_urlsafe(32)
        with database() as db:
            db.execute('BEGIN IMMEDIATE')
            row = manager.row(device_id, db)
            if not row['enabled'] or not row['pair_hash'] or row['pair_expires'] < time.time() or not hmac.compare_digest(row['pair_hash'], digest(body.token)):
                raise HTTPException(403, '配对包已过期或已使用，请重新下载')
            db.execute('''UPDATE egress_devices SET public_key=?,agent_hash=?,pair_hash=NULL,
                          pair_expires=NULL,last_seen=NULL,driver_version=NULL WHERE id=?''',
                       (' '.join(fields), digest(agent_token), device_id))
            manager.event(db, row, 'paired')
            result = {'id': device_id, 'base_url': config['base_url'], 'ssh_host': config['egress_ssh_host'],
                      'ssh_port': 22, 'ssh_user': 'treeroot-egress', 'remote_port': row['port'],
                      'known_hosts': config['egress_known_hosts'], 'proxy_username': device_id,
                      'proxy_password': row['proxy_password'], 'agent_token': agent_token}
        with manager.rate_lock:
            manager.live.pop(device_id, None)
        manager.publish()
        return result

    @app.post('/api/egress/{device_id}/heartbeat')
    def heartbeat(device_id: str, body: HeartbeatEgress, request: Request):
        now = int(time.time())
        with database() as db:
            db.execute('BEGIN IMMEDIATE')
            row = manager.authenticate_agent(device_id, request, db)
            if not row['last_seen'] or now - row['last_seen'] >= 65:
                manager.disconnected(db, row, now)
                manager.event(db, row, 'connected')
            db.executemany('''INSERT OR IGNORE INTO egress_events
                (event_key,device_id,ts,kind,action,outcome,domain,port,method,upload,download,duration_ms,exit_ip,detail)
                VALUES(?,?,?,'request','connection',?,?,?,?,?,?,?,?,?)''',
                ((record.event_key, device_id, record.ts, record.outcome, record.domain, record.port,
                  record.method, record.upload, record.download, record.duration_ms, row['last_ip'] or '', record.detail)
                 for record in body.records if now - 7 * 86400 <= record.ts <= now + 300))
            db.execute('''UPDATE egress_devices SET last_seen=?,driver_version=COALESCE(?,driver_version)
                          WHERE id=?''', (now, body.driver_version, device_id))
            manager.sync_totals(db, device_id)
            blacklist_hosts = [item['host'] for item in manager.blacklist(db, enabled_only=True)]
        manager.sample_traffic(device_id, body.traffic, now)
        manager.publish()
        return {'ok': True, 'accepted': [record.event_key for record in body.records],
                'blacklist': blacklist_hosts}

    @app.get('/api/egress/version')
    def version(session=Depends(authenticated)):
        return {'version': CONNECTOR_VERSION}

    @app.post('/api/egress/{device_id}/test')
    def test(device_id: str, session=Depends(authenticated)):
        with database(readonly=True) as db:
            row = manager.row(device_id, db)
            if not manager.summary(row)['online']:
                raise HTTPException(409, '电脑尚未连接，请先安装并启动连接器')
        configuration = (f'proxy = "http://127.0.0.1:{row["port"]}"\n'
                         f'proxy-user = "{device_id}:{row["proxy_password"]}"\n'
                         'url = "https://myip.ipip.net"\nsilent\nshow-error\nfail\nmax-time = 15\nnoproxy = ""\n')
        try:
            result = subprocess.run(['/usr/bin/curl', '--config', '-'], input=configuration,
                                    capture_output=True, text=True, timeout=18, check=True)
            match = re.search(r'(?:[0-9]{1,3}\.){3}[0-9]{1,3}', result.stdout)
            if not match:
                raise ValueError('IP check response invalid')
            address = str(ipaddress.ip_address(match.group()))
        except (OSError, ValueError, subprocess.SubprocessError):
            with database() as db:
                manager.event(db, row, 'ip_test', 'failed', 'connection_failed')
            raise HTTPException(503, '出口检测失败，请检查电脑网络与连接器状态')
        with database() as db:
            db.execute('UPDATE egress_devices SET last_ip=?,last_test=? WHERE id=?', (address, int(time.time()), device_id))
            manager.event(db, manager.row(device_id, db), 'ip_test')
        return {'ip': address, 'tested_at': int(time.time())}

    return manager
